package edu.asu.msse.gnayak2;

public class Constants {
 public static final int HEIGHT = 600;
 public static final int WIDTH = 400;
}