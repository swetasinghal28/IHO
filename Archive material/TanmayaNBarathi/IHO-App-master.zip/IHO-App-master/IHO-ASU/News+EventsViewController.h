//
//  News+EventsViewController.h
//  IHO
//
//  Created by Cynosure on 11/17/13.
//  Copyright (c) 2013 asu. All rights reserved.
//


#import <sqlite3.h>
#import <UIKit/UIKit.h>

@class NewsDetailViewController;
@class EventDetailsViewController;

@interface News_EventsViewController : UITableViewController


@end
