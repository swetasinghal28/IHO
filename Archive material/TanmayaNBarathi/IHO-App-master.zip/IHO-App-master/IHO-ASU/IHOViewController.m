//
//  IHOViewController.m
//  IHO-ASU
//
//  Created by Cynosure on 4/14/14.
//  Copyright (c) 2014 ASU. All rights reserved.
//

#import "IHOViewController.h"

@interface IHOViewController ()

@end

@implementation IHOViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
