//
//  IHOViewController.h
//  IHO-ASU
//
//  Created by Cynosure on 4/14/14.
//  Copyright (c) 2014 ASU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IHOViewController : UIViewController

@end
