//
//  DonateSiteViewController.h
//  IHO
//
//  Created by Cynosure on 12/10/13.
//  Copyright (c) 2013 asu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DonateSiteViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *asuLink;

@end
