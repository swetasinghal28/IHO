//
//  GalleryOptionsViewController.h
//  IHO
//
//  Created by Cynosure on 4/11/14.
//  Copyright (c) 2014 asu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GalleryOptionsViewController : UIViewController

- (IBAction)Vimeo:(id)sender;
- (IBAction)youTube:(id)sender;

@end
