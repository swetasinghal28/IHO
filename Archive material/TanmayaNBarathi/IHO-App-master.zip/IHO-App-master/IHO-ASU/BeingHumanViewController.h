//
//  BeingHumanViewController.h
//  IHO-ASU
//
//  Created by Cynosure on 4/23/14.
//  Copyright (c) 2014 ASU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeingHumanViewController : UIViewController

- (IBAction)becomingLink:(id)sender;
@end
