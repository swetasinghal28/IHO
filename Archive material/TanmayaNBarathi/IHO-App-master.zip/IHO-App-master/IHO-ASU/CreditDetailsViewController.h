//
//  CreditDetailsViewController.h
//  IHO
//
//  Created by Cynosure on 4/13/14.
//  Copyright (c) 2014 asu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreditDetailsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *creditText;

@end
