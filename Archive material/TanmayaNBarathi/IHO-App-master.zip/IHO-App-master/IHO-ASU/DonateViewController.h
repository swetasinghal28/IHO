//
//  DonateViewController.h
//  IHO
//
//  Created by Cynosure on 11/30/13.
//  Copyright (c) 2013 asu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DonateViewController : UIViewController


@end
